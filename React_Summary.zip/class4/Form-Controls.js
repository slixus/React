import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);

    this.state = { username: '', password: '', description: '', gender: '', yes: false, error: '' };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(e) {
    const isCheckbox = e.target.type === 'checkbox';
    const value = isCheckbox ? e.target.checked : e.target.value;
    this.setState({ [e.target.name]: value, error: '' });
  }

  handleSubmit(e) {
    e.preventDefault();
    if (this.state.username === '') {
      this.setState({ error: 'Username is required' });
      return;
    }
    console.log('submitted state', this.state);
  }

  render() {
    console.log(this.state);
    return (
      <div className="App">
        <form onSubmit={this.handleSubmit}>
          <input name="username" value={this.state.username} onChange={this.handleChange} />
          <input name="password" value={this.state.password} onChange={this.handleChange} />
          <textarea name="description" value={this.state.description} onChange={this.handleChange} />

          <select name="gender" value={this.state.gender} onChange={this.handleChange}>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value=""></option>
          </select>
          <input name="yes" value={this.state.yes} type="checkbox" onChange={this.handleChange} />
          Yes
          <button type="submit">Submit</button>
          {this.state.error}
        </form>
      </div>
    );
  }
}

export default App;
