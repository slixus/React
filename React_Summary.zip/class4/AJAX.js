import React, { Component } from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      dogImages: [],
      isLoading: true
    };
  }

  componentDidMount() {
    // Make request to remote server for data
    axios.get('https://dog.ceo/api/breed/husky/images').then((response) => {
      this.setState({
        dogImages: response.data.message,
        isLoading: false
      });
    });
  }

  render() {
    if (this.state.isLoading) {
      return (
        <div>LOADING</div>
      );
    }
    return (
      <div className="App">
        <ul>
          {this.state.dogImages.map((dogImage) => {
            return (
              <li key={dogImage}>
                <img src={dogImage} style={{ width: 100 }} />
              </li>
            );
          })}
        </ul>
      </div>
    );
  }
}

export default App;
