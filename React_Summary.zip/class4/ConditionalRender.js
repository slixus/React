import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = { color: 'red' };
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    this.setState({ color: 'blue' });
  }

  render() {
    let heading;
    let description;
    if (this.state.color === 'red') {
      heading = (
        <h1>Red</h1>
      );
      description = (
        <p>Some description</p>
      );
    } else {
      heading = (
        <h2>Title</h2>
      );
    }
    return (
      <div style={{ color: this.state.color }} onClick={this.handleClick}>
        {heading}
        {this.state.color === 'red' ? (
          <h1>Red</h1>
        ) : (
          <h2>Title</h2>
        )}
        {description}
        {this.state.color === 'red' && (
          <p>Some description</p>
        )}
      </div>
    );
  }
}

export default App;
