import React, { Component } from 'react';
import Test from './Test';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);

    this.state = {
      count: 0,
      date: new Date(),
      name: null,
      error: false
    };
  }

  componentDidMount() {
    this.interval = setInterval(() => {
      console.log('INTERVAL!');
      this.setState({
        count: this.state.count + 1
      });
      // WRONG: this.state.count = this.state.count + 1;
    }, 2 * 1000);
  }

  componentDidCatch() {
    console.log('componentDidCatch');
    clearInterval(this.interval);
    this.setState({ error: true });
  }

  render() {
    console.log('App render');
    if (this.state.error) {
      return (
        <div>Content not available</div>
      );
    }
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to LifeCycles</h1>
        </header>
        Count: {this.state.count}
        <Test />
      </div>
    );
  }
}

export default App;
