import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class Test extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentWillMount() {
    console.log('componentWillMount');
  }

  componentDidMount() {
    console.log('componentDidMount');
  }

  componentWillUnmount() {
    console.log('componentWillUnmount');
  }

  componentWillReceiveProps() {
    console.log('componentWillReceiveProps');
  }

  componentWillUpdate() {
    console.log('componentWillUpdate');
  }

  componentDidUpdate() {
    console.log('componentDidUpdate');
  }

  componentDidCatch() {
    console.log('componentDidCatch');
  }

  // static getDerivedStateFromProps() {
  //   console.log('getDerivedStateFromProps');
  //   return null;
  // }

  // getSnapshotBeforeUpdate() {
  //   console.log('getSnapshotBeforeUpdate');
  // }

  shouldComponentUpdate() {
    console.log('shouldComponentUpdate');
    return true;
  }

  render() {
    return (
      <div className="App">
        TEST
      </div>
    );
  }
}

export default Test;
