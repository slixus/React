import React, { Component } from 'react';

class Test extends Component {
  // componentWillMount() {
  //   console.log('componentWillMount');
  // }

  componentWillUnmount() {
    console.log('componentWillUnmount');
  }

  componentDidMount() {
    console.log('componentDidMount');
  }

  // componentWillReceiveProps(prevProps) {
  //   console.log('componentWillReceiveProps');
  // }
  //
  // componentWillUpdate() {
  //   console.log('componentWillUpdate');
  // }

  componentDidUpdate(prevProps) {
    // if (this.props.id !== prevProps.id) {
    //
    //   this.setState({ item: 'someItem '});
    // }
    console.log('componentDidUpdate');
  }

  static getDerivedStateFromProps() {
    console.log('getDerivedStateFromProps');
    return null;
  }

  getSnapshotBeforeUpdate(prevProps) {
    console.log('getSnapshotBeforeUpdate');
  }


  render() {
    return (
      <div>Test</div>
    );
  }
}

export default Test;
