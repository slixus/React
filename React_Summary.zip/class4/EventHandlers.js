import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
      buttonColor: 'red'
    };
    this.handleClick = this.handleClick.bind(this);
    this.handleLinkClick = this.handleLinkClick.bind(this);
    this.handleMouseEnter = this.handleMouseEnter.bind(this);
    this.handleMouseLeave = this.handleMouseLeave.bind(this);
  }

  handleClick() {
    console.log(this);
    this.setState({ counter: this.state.counter + 1 });
  }

  handleLinkClick(event) {
    console.log(event);
    event.preventDefault();
  }

  handleMouseEnter() {
    this.setState({ buttonColor: 'blue' });
  }

  handleMouseLeave() {
    this.setState({ buttonColor: 'red' });
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
        Counter: {this.state.counter}
        <button
          style={{ backgroundColor: this.state.buttonColor }}
          onMouseEnter={this.handleMouseEnter}
          onMouseLeave={this.handleMouseLeave}
          onClick={this.handleClick}
        >
          Click here
        </button>
        <a href="https://google.ca" onClick={this.handleLinkClick}>google</a>
      </div>
    );
  }
}

export default App;
