import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import './App.css';
import WeatherApp from './WeatherApp';
import ToDoApp from './ToDoApp';
import Home from './Home';
import Page from './Page';
import NotFound from './NotFound';

class App extends Component {

  apiUrl = 'https://query.yahooapis.com/v1/public/yql?format=json&q=select * from weather.forecast where woeid in (select woeid from geo.places(1) where text="';

  constructor(props) {
    super(props);

    // always object!!
    this.state = { list: [], clas: "red", city: "Burnaby, BC", title: "" };

    // This binding is necessary to make `this` work in the callback
    // this.doRequest = this.doRequest.bind(this);
  }






  render() {
    return (
      <Router>
        <div>
          <h1>Browser Router</h1>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/Weather-App">Weather App</Link>
            </li>
            <li>
              <Link to="/ToDo-App">ToDo App</Link>
            </li>
            <li>
              <Link to="/Pages/1">Page 1</Link>
            </li>
            <li>
              <Link to="/Pages/2">Page 2</Link>
            </li>
          </ul>

          <hr />

          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/Weather-App" component={WeatherApp} />
            <Route path="/ToDo-App" component={ToDoApp} />
            <Route path="/Pages/:id" component={Page} />
            <Route component={NotFound} />
          </Switch>

        </div>
      </Router>
    );
  }



}

export default App;
