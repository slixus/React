import React, { Component } from 'react';


function Page(props) {

    return (
      <h1>Page {props.match.params.id}</h1>
    );

}

export default Page;
