import React, { Component } from 'react';
import './App.css';

class RPSbtn extends Component {

  constructor(props) {
    super(props);

    this.btnClick = this.btnClick.bind(this);
  }

  btnClick() {
    this.props.onClick(this.props.choice);
  }

  render() {
    return (
      <button
        onClick={this.btnClick}
        disabled={(this.props.isStopped ? 'disabled' : "")}>

        {this.props.name}
      </button>
    );
  }


}

export default RPSbtn;
