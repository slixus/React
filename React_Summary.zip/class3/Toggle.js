import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class Toggle extends React.Component {


  constructor(props) {
    super(props);

    // always object!!
    this.state = {isToggleOn: true, msg: props.msg, btnColorOn: false };

    // This binding is necessary to make `this` work in the callback
    this.handleClick = this.handleClick.bind(this);
    this.handleColorOver = this.handleColorOver.bind(this);
  }


  handleClick() {
    // setState
    this.setState(state => ({
      isToggleOn: !state.isToggleOn
    }));
  }
  handleColorOver() {
    // setState
    this.setState(state => ({
      btnColorOn: !state.btnColorOn
    }));
  }




    render() {
      return (
        <button onClick={this.handleClick}
          onMouseEnter={this.handleColorOver}  onMouseLeave={this.handleColorOver}
          style={this.state.btnColorOn ? {backgroundColor: "blue"} : {backgroundColor: "white"}}>
          {this.state.isToggleOn ? 'ON' : this.state.msg ? this.state.msg : "NOP"}
        </button>
      );
    }

  componentWillReceiveProps() {
    console.log('componentWillReceiveProps');
  }

}


export default Toggle;
