import React, { Component } from 'react';


class StopWatch extends React.Component {


  constructor(props) {
    super(props);

    // always object!!
    this.state = { timer: 0 };

    // This binding is necessary to make `this` work in the callback
    this.handleClick = this.handleClick.bind(this);
  }


  handleClick() {
    // setState
    this.setState(state => ({ timer: state.timer + 1 }));
    //console.log(this.state.timer);
  }


  render() {
    return (
      <div>
        <h1>Stop-watch App!</h1>
        <h2>TIMER: {("0"+(this.state.timer%60).toString())}</h2>
      </div>
    );
  }

  componentDidMount() {
    setInterval(this.handleClick, 1000);
  }
}
// WRONG - use eventoverride!

export default StopWatch;
