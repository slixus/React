import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import App from './App';
import Sw from './StopWatch';
import Toggle from './Toggle';

import registerServiceWorker from './registerServiceWorker';



ReactDOM.render(<Sw />, document.getElementById('sw'));


ReactDOM.render(
  <div><App /><Toggle msg="OFF???" /></div>,
  document.getElementById('root')
);




function tick() {
  const element = (
    <div>
      <h1>Hello, world!</h1>
      <h2>It is {new Date().toLocaleTimeString()}.</h2>
    </div>
  );
  // highlight-next-line
  ReactDOM.render(element, document.getElementById('main'));
}

setInterval(tick, 1000);






registerServiceWorker();
