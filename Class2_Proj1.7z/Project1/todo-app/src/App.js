import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {

  statics = { iniMsg: "<center>Nothing yet...</center>" }

  constructor(props) {
    super(props);

    // always object!!
    this.state = { isEmpty: true, list: this.statics.iniMsg, clas: "red"};

    // This binding is necessary to make `this` work in the callback
    this.addBtnClick = this.addBtnClick.bind(this);
    this.keyPress = this.keyPress.bind(this);
  }


  addBtnClick() {
    var read = document.getElementById("inputMe").value.trim();

    if (read.length > 0)
    {
      var newItem = "<li>" + (new Date()).toLocaleDateString() + " " + (new Date()).toLocaleTimeString()
          + " <input type='checkbox' onclick='this.parentElement.outerHTML=``' /> " + read + "</li>";
      if (this.state.list == this.statics.iniMsg)
        this.setState(state => ({ list: newItem }));
      else
        this.setState(state => ({ list: state.list + newItem }));

      this.showMsg("Added item...", "green");
    }
    else
      this.showMsg("Empty input...", "red");

    document.getElementById("inputMe").value = "";
  }


  keyPress(e) {
    //console.log(e.keyCode);
    if (e.keyCode == 13)
      this.addBtnClick();
  }


  showMsg(msg, clas, timeout) {
    // setState
    this.setState(state => ({ msg: msg}));
    if (clas !== undefined)
      this.setState(state => ({ clas: clas}));

    setTimeout(()=>{this.setState(state => ({ msg: "" }));}, 5000)
  }



  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">TODO App</h1>
        </header>

        <p className="App-intro">
          <label>Input TODO item:</label>&nbsp;
          <input type="text" id="inputMe"  onKeyUp={this.keyPress} tabIndex="0"/>
          <button onClick={this.addBtnClick}>Add TODO Item</button>
        </p>
        <div className={this.state.clas} id="msgbox">&nbsp;{this.state.msg}</div>

        <h2>TODO List</h2>

        <ul id="todoul" dangerouslySetInnerHTML={{__html: this.state.list}} />

      </div>
    );
  }



}

export default App;
