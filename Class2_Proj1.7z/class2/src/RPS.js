import React, { Component } from 'react';
import './App.css';

class RPS extends Component {

  constructor(props) {
    super(props);

    // always object!!
    this.state = { human: 0, computer: 0, isStopped: false, msg: "Start the game by selecting your Rock-Paper-Scissors."};

    // This binding is necessary to make `this` work in the callback
    this.btnClick = this.btnClick.bind(this);
    this.handleResetBtnClick = this.handleResetBtnClick.bind(this);
  }


  btnClick(sender) {
    // setState
    var comp = Math.floor((Math.random() * 3) + 1);
    if (comp==sender)
    {
      this.showMsg("Draw... comp said: " + comp);
    }
    else
      if (this.isWon(sender, comp)) {
        this.setState(state => ({ human: state.human+1 }));
        this.showMsg("You won this time! - comp said: " + comp );

        if (this.state.human >= 4)
        {
          setTimeout(()=> { this.showMsg("Game over: VICTORY! :-)") }, 800);
          this.setState(state => ({ isStopped: true }));
        }
      }
      else {
        this.setState(state => ({ computer: state.computer+1 }));
        this.showMsg("Computer won this time! - comp said: " + comp );

        if (this.state.computer >= 4)
        {
          setTimeout(()=> { this.showMsg("Game over: FAILURE! :-(") }, 800);
          this.setState(state => ({ isStopped: true }));
        }
      }
  }

  handleResetBtnClick() {
    // setState
    this.setState(state => ({ human: 0 }));
    this.setState(state => ({ computer: 0 }));
    this.showMsg("Start the game by selecting your Rock-Paper-Scissors." );
    this.setState(state => ({ isStopped: false }));
  }


  showMsg(msg) {
    // setState
    this.setState(state => ({ msg: msg}));
    document.getElementById("msgbox").classList.add("anima");
    setTimeout(()=>{document.getElementById("msgbox").classList.remove("anima");}, 500)
  }

  isWon(you, comp) {
    if (you > comp && !(you == 3 && comp == 1) || you == 1 && comp == 3)
      return true;
    if (you < comp && !(you == 1 && comp == 3) || you == 3 && comp == 1 )
      return false;

    return true;
  }




  render() {
    return (
      <div>
        <h1>Rock-Paper-Scissors!</h1>
        <table className="tblRPS border1">
        <tbody>
          <tr><td>HUMAN</td><td>COMPUTER</td></tr>
          <tr><td>{this.state.human}</td><td>{this.state.computer}</td></tr>
          </tbody>
        </table>
        <br/><br/>
        <div className="tblRPS red" id="msgbox">{this.state.msg}</div>
        <br/><br/>

        <table className="tblRPS">
        <tbody>
          <tr>
            <td><button onClick={() => this.btnClick(1)} disabled={(this.state.isStopped ? 'disabled' : "")}>ROCK</button></td>
            <td><button onClick={() => this.btnClick(2)} disabled={(this.state.isStopped ? 'disabled' : "")}>PAPER</button></td>
            <td><button onClick={() => this.btnClick(3)} disabled={(this.state.isStopped ? 'disabled' : "")}>SCISSORS</button></td>
          </tr>
          </tbody>
        </table>
        <br/><br/>
        <button onClick={this.handleResetBtnClick}>
          Reset
        </button>
      </div>
    );
  }


}

export default RPS;
