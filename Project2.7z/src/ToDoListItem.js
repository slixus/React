import React, { Component } from 'react';

class ListItem extends Component {

  render() {
    return (
      <li key={this.props.idx}>{(this.props.date)+ " " + (this.props.date)}
        <input type='checkbox' onClick={() => { this.props.callback(this.props.idx) }} />{this.props.text}
      </li>
    );
  }

}

export default ListItem;
