import React, { Component } from 'react';
import logo from './logo.svg';
import axios from 'axios';
import './App.css';
import Forecast from './Forecast';
import CitySelector from './CitySelector';

class WeatherApp extends Component {


  constructor(props) {
    super(props);

    // always object!!
    this.state = { list: [], clas: "red", city: "Burnaby, BC" };
    this.index = 0;
    this.timeout = 0;

    this.apiUrl = 'https://query.yahooapis.com/v1/public/yql?format=json&q=select * from weather.forecast where woeid in (select woeid from geo.places(1) where text="';

    // This binding is necessary to make `this` work in the callback
    this.citySelectorHandler = this.citySelectorHandler.bind(this);
    this.doRequest = this.doRequest.bind(this);
  }

  componentDidMount() {
    this.doRequest();
  }

  doRequest() {
    axios.get(`${this.apiUrl}${this.state.city}")`).then((resp) => {
      console.log(resp);
      this.setState({
        list: resp.data.query.results.channel.item.forecast
      });
    });
  }

  // add todo item btn event handler
  citySelectorHandler() {
    this.doRequest();
  }


  showMsg(msg, clas, timeout) {
    this.setState(state => ({ msg: msg}));
    if (clas !== undefined)
      this.setState(state => ({ clas: clas}));

    clearTimeout(this.timeout);  // show the message for 5 secs
    this.timeout = setTimeout(()=>{this.setState(state => ({ msg: "" }));}, 5000)
  }



  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Weather App</h1>
          <h5>by Sergey Liksutin</h5>
        </header>

        <p className="App-intro">
          <CitySelector city={this.state.city} onchange={this.citySelectorHandler} />
        </p>
        <div className={this.state.clas} id="msgbox">&nbsp;{this.state.msg}</div>

        <h3>10 Days Forecast for {this.state.city}</h3>

        <Forecast list={this.state.list} />

      </div>
    );
  }



}

export default WeatherApp;
