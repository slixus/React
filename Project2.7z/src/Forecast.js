import React, { Component } from 'react';
import ToDoListItem from './ToDoListItem';


class Forecast extends Component {

  render() {

    if (this.props.list.length > 0)
    {
      let list = this.props.list;
      const listItems = list.map((item) =>
        <ToDoListItem date={item.date} text={item.text} callback={this.props.callback}  key={item.index} idx={item.index} />
      )
      return (
        <ul id="todoul">{listItems}</ul>
      );
    }
    else // if empty - show "Empty" message
    {
      return (
        <ul id="todoul"><li>Nothing yet...</li></ul>
      );
    }


  }

}

export default Forecast;
