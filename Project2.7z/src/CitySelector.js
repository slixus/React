import React, { Component } from 'react';


class CitySelector extends Component {

  render() {
    return (
      <div>
        <label>Select a City: </label>
        <select value={this.props.city} onChange={this.props.onchange}>
          <option value="Burnaby, BC">Burnaby</option>
          <option value="new york, ny">New York</option>
          <option value="moscow, russia">Moscow</option>
          <option value="paris, france">Paris</option>
          <option value="london, gb">London</option>
        </select>
      </div>
    );
  }

}

export default CitySelector;
