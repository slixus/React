import React, { Component } from 'react';

class ForecastDay extends Component {

  render() {
    return (
      <li key={this.props.item.date} className="liDay">

        <span style={{float: "left", padding: "10px 10px 2px 10px", width: 100, textAlign: "center"}}>
          <b>{this.props.item.day}</b><br/>
          <small style={{color: "#777"}}>{this.props.item.date}</small>
        </span>

        <span style={{float: "left", padding: "0px 5px", width: 170, verticalAlign: "middle"}}>
          <img src={`https://s.yimg.com/zz/combo?a/i/us/we/52/${this.props.item.code}.gif`} alt={this.props.item.text}
             style={{float: "left", padding: "3px 10px"}} />

          <small><br/>{this.props.item.text}</small>
        </span>

        <span style={{float: "left", padding: "3px 10px", width: 100}}>
          <span style={{color:"#500"}}>High: {this.f2c(this.props.item.high)}&deg;C</span>
          <small style={{lineHeight: "7px"}}><br/><br/> </small>
          <span style={{color:"#008"}}>Low: {this.f2c(this.props.item.low)}&deg;C</span>
        </span>

      </li>
    );
  }

  f2c(fahren) {
    return Math.round((fahren - 32) * .5556);
  }

}

export default ForecastDay
