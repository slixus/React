import React, { Component } from 'react';
import axios from 'axios';
import './App.css';
import Forecast from './Forecast';
import CitySelector from './CitySelector';

class WeatherApp extends Component {

  apiUrl = 'https://query.yahooapis.com/v1/public/yql?format=json&q=select * from weather.forecast where woeid in (select woeid from geo.places(1) where text="';

  constructor(props) {
    super(props);

    // always object!!
    this.state = { list: [], clas: "red", city: "Burnaby, BC", title: "" };

    // This binding is necessary to make `this` work in the callback
    this.citySelectorHandler = this.citySelectorHandler.bind(this);
    this.doRequest = this.doRequest.bind(this);
  }

  componentDidMount() {
    this.doRequest(this.state.city);
  }

  doRequest(city) {
    // https://kapeli.com/cheat_sheets/Axios.docset/Contents/Resources/Documents/index
    this.setState({ list: [{text: "LOADING..."}] });
    this.setState({ title: city });

    axios.get(`${this.apiUrl}${city}")`)
      .then((resp) => {
        //console.log(resp);
        if (resp.data.query.results != null)
        {
          this.setState({ list: resp.data.query.results.channel.item.forecast });
          this.setState({ title: resp.data.query.results.channel.description });
        }
        else {
          this.showMsg("Error: Y! sent me a NULL!");
          // setting test data instead:
          this.setState({ title: "Y! Fails... USING TEST DATA" });
          this.setState({
            list: [
              {code: 28, date: "5 Oct 2018", high: 78, low: 39, day: "Sun", text: "Party Cloudy"},
              {code: 0, date: "6 Oct 2018", high: 85, low: 48, day: "Mon", text: "OMG!"}]
            });
        }
      })
      .catch((error) => {
        this.showMsg(error);
        this.setState({ list: [{text: "Request Failed!"}] });        
      });
  }


  citySelectorHandler(e) {
    this.setState({city: e.target.value});
    this.doRequest(e.target.value);
  }


  showMsg(msg, clas = "red", timeout = 5000) {
    this.setState(state => ({ msg: msg.toString()}));
    if (clas !== undefined)
      this.setState(state => ({ clas: clas}));

    clearTimeout(this.timeout);  // show the message for 5 secs
    this.timeout = setTimeout(()=>{this.setState(state => ({ msg: "" }));}, timeout)
  }



  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">Weather App</h1>
          <h5>by Sergey Liksutin</h5>
        </header>

        <p className="App-intro">
          <CitySelector city={this.state.city} onchange={this.citySelectorHandler} />
        </p>
        <div className={this.state.clas} id="msgbox">&nbsp;{this.state.msg}</div>

        <h3>{this.state.title}</h3>

        <Forecast list={this.state.list} />

      </div>
    );
  }



}

export default WeatherApp;
