import React, { Component } from 'react';


class CitySelector extends Component {

  render() {
    return (
      <span>
        <label>Select a City: </label>
        <select value={this.props.city} onChange={this.props.onchange}>
          <option value="Burnaby, BC">Burnaby</option>
          <option value="New York, NY">New York</option>
          <option value="Moscow, Russia">Moscow</option>
          <option value="Paris, France">Paris</option>
          <option value="London, GB">London</option>
          <option value="@&*()>">Test Error</option>
        </select>
      </span>
    );
  }

}

export default CitySelector;
