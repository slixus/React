import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ToDoList from './ToDoList';

class ToDoApp extends Component {

  constructor(props) {
    super(props);

    // always object!!
    this.state = { list: [], clas: "red", sorttitle: "Sort ∧∨" };
    this.index = 0;
    this.timeout = 0;

    // This binding is necessary to make `this` work in the callback
    this.addBtnClick = this.addBtnClick.bind(this);
    this.sortBtnClick = this.sortBtnClick.bind(this);
    this.keyPress = this.keyPress.bind(this);
    this.callBack = this.callBack.bind(this);
  }


  // add todo item btn event handler
  addBtnClick() {
    let read = document.getElementById("inputMe").value.trim();

    if (read.length > 0)
    {
      let push = this.state.list;
      this.index++;
      push.push({ index: this.index, date: new Date(), text: read });
      this.setState(state => ({ list: push }));

      this.showMsg("Added new item.", "green");
    }
    else
      this.showMsg("Empty input...", "red");

    document.getElementById("inputMe").value = "";
  }


  // sort it!
  sortBtnClick() {
    let newList = this.state.list;
    if (this.state.sorttitle === "Sort ∧")
    {
      this.setState(state => ({ sorttitle: "Sort ∨" }));
      newList.sort((o1,o2) => { return o2.date - o1.date;});
    }
    else {
      this.setState(state => ({ sorttitle: "Sort ∧" }));
      newList.sort((o1,o2) => { return o1.date - o2.date;});
    }
    this.setState(state => ({ list: newList }));
  }



  // to catch <Enter> on todo item input
  keyPress(e) {
    if (e.keyCode === 13)
      this.addBtnClick();
  }


  // onChecked
  callBack(idx) {
    let newList = this.state.list;
    let index = newList.findIndex(item => item.index === idx);
    if (index !== -1)
    {
      newList.splice(index, 1);
      this.setState(state => ({ list: newList }));
      this.showMsg("Item completed and removed - id=" + idx, "blue");
    }
  }


  showMsg(msg, clas, timeout) {
    this.setState(state => ({ msg: msg}));
    if (clas !== undefined)
      this.setState(state => ({ clas: clas}));

    clearTimeout(this.timeout);  // show the message for 5 secs
    this.timeout = setTimeout(()=>{this.setState(state => ({ msg: "" }));}, 5000)
  }



  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">TODO List App</h1>
          <h5>by Sergey Liksutin</h5>
        </header>

        <p className="App-intro">
          <label>Input Your Task:</label>&nbsp;
          <input type="text" id="inputMe"  onKeyUp={this.keyPress} tabIndex="0"/>
          <button onClick={this.addBtnClick}>Add TODO Item</button>
        </p>
        <div className={this.state.clas} id="msgbox">&nbsp;{this.state.msg}</div>

        <h3>TODO List</h3>

        <div id="sortdiv">
          <button id="sortbtn" onClick={this.sortBtnClick}>{this.state.sorttitle}</button>
        </div>

        <ToDoList list={this.state.list} callback={this.callBack} />

      </div>
    );
  }



}

export default ToDoApp;
