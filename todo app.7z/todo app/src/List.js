import React, { Component } from 'react';
import ListItem from './ListItem';


class List extends Component {

  render() {

    // cut out the first element ("Nothing yet...") if more than 1 in the list
    let list = this.props.list.slice(this.props.list.length > 1);

    const listItems = list.map((item) =>
      <ListItem date={item.date} text={item.text} callback={this.props.callback}  key={item.index} idx={item.index} />
    )

    return (
      <ul id="todoul">{listItems}</ul>
    );

  }

}

export default List;
