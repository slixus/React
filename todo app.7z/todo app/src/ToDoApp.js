import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import List from './List';

class ToDoApp extends Component {

  statics = { iniMsg: "Nothing yet..." }

  constructor(props) {
    super(props);

    // always object!!
    this.state = { list: [{ index: 0, date: new Date(), text: this.statics.iniMsg}], clas: "red" };
    this.index = 0;
    this.timeout = 0;

    // This binding is necessary to make `this` work in the callback
    this.addBtnClick = this.addBtnClick.bind(this);
    this.keyPress = this.keyPress.bind(this);
    this.callBack = this.callBack.bind(this);
  }


  addBtnClick() {
    let read = document.getElementById("inputMe").value.trim();

    if (read.length > 0)
    {
      let push = this.state.list;
      this.index++;
      push.push({ index: this.index, date: new Date(), text: read });
      this.setState(state => ({ list: push }));

      this.showMsg("Added new item.", "green");
    }
    else
      this.showMsg("Empty input...", "red");

    document.getElementById("inputMe").value = "";
  }


  keyPress(e) {
    //console.log(e.keyCode);
    if (e.keyCode === 13)
      this.addBtnClick();
  }


  callBack(idx) {
    //console.log("callBack func -> idx=" + idx);
    let newList = this.state.list;
    let index = newList.findIndex(item => item.index === idx);
    if (index !== -1)
    {
      newList.splice(index, 1);
      this.setState(state => ({ list: newList }));
      this.showMsg("Item completed and removed - id=" + idx, "blue");
    }
  }


  showMsg(msg, clas, timeout) {
    // setState
    this.setState(state => ({ msg: msg}));
    if (clas !== undefined)
      this.setState(state => ({ clas: clas}));

    clearTimeout(this.timeout);
    this.timeout = setTimeout(()=>{this.setState(state => ({ msg: "" }));}, 5000)
  }



  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">TODO List App</h1>
        </header>

        <p className="App-intro">
          <label>Input TODO item:</label>&nbsp;
          <input type="text" id="inputMe"  onKeyUp={this.keyPress} tabIndex="0"/>
          <button onClick={this.addBtnClick}>Add TODO Item</button>
        </p>
        <div className={this.state.clas} id="msgbox">&nbsp;{this.state.msg}</div>

        <h2>TODO List</h2>

        <List list={this.state.list} callback={this.callBack} />

      </div>
    );
  }



}

export default ToDoApp;
