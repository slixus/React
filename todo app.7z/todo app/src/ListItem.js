import React, { Component } from 'react';

class ListItem extends Component {

  render() {
    //console.log(this.props.idx);
    if (this.props.idx !== 0)
      return (
        <li key={this.props.idx}>{(this.props.date).toLocaleDateString() + " " + (this.props.date).toLocaleTimeString()}
          <input type='checkbox' onClick={() => { this.props.callback(this.props.idx) }} />{this.props.text}
        </li>
      );
    else
      return (
        <li key={this.props.idx}>{this.props.text}</li>
      )

  }

}

export default ListItem;
