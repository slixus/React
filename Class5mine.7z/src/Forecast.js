import React, { Component } from 'react';
import ForecastDay from './ForecastDay';


class Forecast extends Component {

  render() {

    if (this.props.list.length > 0)
    {
      if (this.props.list.length === 1) // loading scenario...
      {
        return (
          <ul id="todoul"><li style={{textAlign : 'center'}}>{this.props.list[0].text}</li></ul>
        );
      }
      else
      {
        let list = this.props.list;
        const listItems = list.map((item) =>
            <ForecastDay item={item} key={item.date}  />
          );
        return (
          <ul id="todoul">{listItems}</ul>
        );
      }
    }
    else // if empty - show "Empty" message
    {
      return (
        <ul id="todoul"><li>Nothing is found...</li></ul>
      );
    }

  } // end render


}


export default Forecast;
