import React, { Component } from 'react';


class NotFound extends Component {

  render() {

    return (
      <h1>Page Not found</h1>
    );

  }

}

export default NotFound;
