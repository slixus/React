import React, { Component } from 'react';

class StopWatch extends React.Component {


  constructor(props) {
    super(props);

    // always object!!
    this.state = { timer: 0, isStopped: false };

    // This binding is necessary to make `this` work in the callback
    this.handleTimer = this.handleTimer.bind(this);
    this.handlePauseBtnClick = this.handlePauseBtnClick.bind(this);
    this.handleResetBtnClick = this.handleResetBtnClick.bind(this);
  }


    handleTimer() {
      // setState
      this.setState(state => ({ timer: state.timer + 1 }));
    }

    handlePauseBtnClick() {
      // setState
      if (this.state.isStopped)
        this.myInterval = setInterval(this.handleTimer, 1000);
      else
        clearInterval(this.myInterval);

      this.setState(state => ({ isStopped: !state.isStopped }));
    }

    handleResetBtnClick() {
      // setState
      this.setState(state => ({ timer: 0 }));
      this.setState(state => ({ isStopped: !state.isStopped }));
      clearInterval(this.myInterval);
    }


  render() {
    return (
      <div>
        <h1>Stop-watch App!</h1>
        <h2>TIMER: {( ("00" + Math.floor(this.state.timer/60, 2)).slice(-2)
                      + ":" + ("00" + (this.state.timer%60).toString()).slice(-2) )}</h2>
        <button onClick={this.handlePauseBtnClick}>
          {this.state.isStopped ? "Start" : 'Pause' }
        </button>
        &nbsp;&nbsp;
        <button onClick={this.handleResetBtnClick} disabled={(this.state.isStopped ? 'disabled' : "")}>
          Reset
        </button>
      </div>
    );
  }

  componentDidMount() {
    this.myInterval = setInterval(this.handleTimer, 1000);
  }

}

export default StopWatch;
