import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
componentDidMount() {
  console.log("componentDidlMount");
}

  render() {
    console.log("rendering...");

    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <p className="App-intro">
        {this.props ? this.props.toString() : "noppy"}
        <a href="stopwatch.html">stopwatch</a>
        </p>
      </div>
    );
  }
}

export default App;
