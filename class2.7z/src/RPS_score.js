import React, { Component } from 'react';
import './App.css';

class RPS2 extends Component {

  render() {
    return (
        <table className="tblRPS border1">
        <tbody>
          <tr><td>HUMAN</td><td>COMPUTER</td></tr>
          <tr><td>{this.props.human}</td><td>{this.props.computer}</td></tr>
          </tbody>
        </table>
    );
  }


}

export default RPS2;
