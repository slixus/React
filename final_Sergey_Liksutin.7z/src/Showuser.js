import React, { Component } from 'react';

class Showuser extends Component {

  render() {

    let usFlagTag=(
      <img src="http://aux.iconspalace.com/uploads/2025710045.png" alt="US"
         style={{padding: "3px 10px", height: 25}} />
       );

    if (this.props.item.nat !== "US")
      usFlagTag="";

    let genderUrl = "https://vignette.wikia.nocookie.net/dumbledoresarmyroleplay/images/4/46/Female_icon.png/revision/latest?cb=20120603115847";
    if (this.props.item.gender === "male")
      genderUrl = "http://icons.iconarchive.com/icons/aha-soft/dating/256/male-icon.png";

    return (
      <li key={this.props.item.email} className="liDay">

        <span style={{float: "left", padding: "0px 5px", width: 170, verticalAlign: "middle"}}>
          <img src={`${this.props.item.picture.thumbnail}`} alt="user"
             style={{float: "left", padding: "3px 10px"}} />
          <img src={`${genderUrl}`} alt="gender"
             style={{padding: "3px 10px", height: 20}} />

          {usFlagTag}

          <small><br/>{this.props.item.name.first} {this.props.item.name.last}</small>
        </span>

        <span style={{padding: "10px 10px 2px 10px", width: 100, textAlign: "center"}}>
          <small><b>City:</b> {this.props.item.location.city}, <b>State:</b> {this.props.item.location.state}</small><br/>
          <small><b>Email:</b> {this.props.item.email}</small>
        </span>

        <br/>
        <button onClick={() => { this.props.callback(this.props.idx) }}>Delete</button>

      </li>
    );
  }


}

export default Showuser
