import React, { Component } from 'react';
import axios from 'axios';
import './App.css';
import Showlist from './Showlist';

class App extends Component {

  apiUrl = 'https://randomuser.me/api/?results=25';


  constructor(props) {
    super(props);

    this.state = { list: [], msg: "" };

    // This binding is necessary to make `this` work in the callback
    this.doRequest = this.doRequest.bind(this);
    this.callBack = this.callBack.bind(this);
  }

  componentDidMount() {
    this.doRequest();
  }


  doRequest() {
    this.showMsg("loading...");

    axios.get(`${this.apiUrl}`)
      .then((resp) => {
        if (resp.data.results != null)
        {
          this.setState({ list: resp.data.results });
          this.showMsg("");
        }
        else {
          this.showMsg("Error: API request failed!");
        }
      })
      .catch((error) => {
        this.showMsg(error);
        this.setState({ list: [{text: "API Request Failed!"}] });
      });
  }


  // delete
  callBack(idx) {
    let newList = this.state.list.slice(0); // clone the array
    let index = newList.findIndex(item => item.email === idx);
    if (index !== -1)
    {
      newList.splice(index, 1);

      this.setState(state => ({ list: newList }));
      this.showMsg("User removed - id=" + idx, "blue");
    }
  }


  showMsg(msg, clas = "red", timeout = 5000) {
    this.setState(state => ({ msg: msg.toString()}));
    if (clas !== undefined)
      this.setState(state => ({ clas: clas}));

    clearTimeout(this.timeout);  // show the message for 5 secs
    this.timeout = setTimeout(()=>{this.setState(state => ({ msg: "" }));}, timeout)
  }



    render() {
      return (
        <div className="App">
          <header className="App-header">
            <h1 className="App-title">Final Project</h1>
            <h5>by Sergey Liksutin</h5>
          </header>

          <h3>User List</h3>

          <div className={this.state.clas} id="msgbox">&nbsp;{this.state.msg}</div>

          <Showlist list={this.state.list}  callback={this.callBack} />

        </div>
      );
    }




}

export default App;
