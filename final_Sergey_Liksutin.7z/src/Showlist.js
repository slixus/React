import React, { Component } from 'react';
import Showuser from './Showuser';


class Showlist extends Component {

  render() {

    if (this.props.list.length > 0)
    {
        let list = this.props.list;
        const listItems = list.map((item) =>
            <Showuser item={item} callback={this.props.callback}
                      key={item.email} idx={item.email} />
          );
        return (
          <ul id="todoul">{listItems}</ul>
        );
    }
    else // if empty - show "Empty" message
    {
      return (
        <ul id="todoul"><li>The list is empty...</li></ul>
      );
    }

  } // end render


}

export default Showlist;
